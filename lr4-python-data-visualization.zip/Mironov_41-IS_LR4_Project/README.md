# Лабораторная работа № 4 — Визуализация данных в Python

**Автор:** Миронов А. П.  
**Группа:** 41-ИС  
**Дисциплина:** «Интеллектуальные системы и технологии»  
**Набор данных:** Telco Customer Churn (IBM / Kaggle).

## Описание проекта

Проект предназначен для загрузки, подготовки, анализа и визуализации сведений о клиентах телекоммуникационного оператора. Исходный набор содержит 7 043 записи и 21 поле. После подготовки добавляется признак `ChurnFlag`, поэтому рабочая таблица содержит 22 столбца.

В проекте выполнены четыре задания лабораторной работы:

1. Распределение `TotalCharges` и сравнение статистик `TotalCharges` и `MonthlyCharges` с использованием Matplotlib, Seaborn и Plotly.
2. Тепловая карта сочетания `PaymentMethod × Contract`: численность групп и доля оттока.
3. Кривые оттока по сроку обслуживания `tenure` для трёх типов договора; данные показываются по месяцам и полугодиям.
4. Сопоставление корректной и намеренно искажённой диаграммы доли оттока по способу оплаты.

Помимо графиков программа сохраняет сводные таблицы и краткую сводку запуска.

## Структура проекта

```text
Mironov_41-IS_LR4_Project/
├── data/
│   └── WA_Fn-UseC_-Telco-Customer-Churn.csv
├── telco_viz/
│   ├── __init__.py
│   ├── __main__.py
│   ├── config.py
│   ├── data.py
│   ├── analysis.py
│   ├── static_plots.py
│   ├── interactive_plots.py
│   └── cli.py
├── tests/
│   └── test_project.py
├── reports/
│   ├── figures/
│   ├── interactive/
│   ├── tables/
│   └── run_summary.txt
├── requirements.txt
├── run_windows.bat
└── README.md
```

## Запуск в Windows / Visual Studio Code

1. Установить Python 3.10 или новее.
2. Открыть папку проекта в Visual Studio Code.
3. Открыть терминал в этой папке.
4. Установить зависимости и запустить программу:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m telco_viz
```

Также можно запустить файл `run_windows.bat` двойным щелчком мыши.

Чтобы пропустить интерактивные графики Plotly:

```bash
python -m telco_viz --no-plotly
```

## Проверка программы

Установить зависимости уже включает `pytest`. Запуск тестов:

```bash
python -m pytest -q
```

Тесты проверяют размер таблицы, количество пропусков, долю оттока, статистики платежей и ключевые результаты группировки по способу оплаты и договору.

## Результаты

После запуска файлы сохраняются в папку `reports/`:

- `figures/` — 6 статических PNG-графиков;
- `interactive/` — 4 интерактивных графика Plotly в HTML;
- `tables/` — CSV-таблицы с расчётами;
- `run_summary.txt` — краткая сводка выполнения.

Интерактивные HTML-файлы открываются обычным браузером.

## Использованные источники

- IBM, Telco Customer Churn CSV: <https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv>
- Kaggle, Telco Customer Churn: <https://www.kaggle.com/datasets/blastchar/telco-customer-churn>
- Matplotlib documentation: <https://matplotlib.org/stable/>
- Seaborn documentation: <https://seaborn.pydata.org/>
- Plotly Python documentation: <https://plotly.com/python/>

## Ограничения анализа

Полученные результаты описывают связи внутри предоставленного набора данных. Они сами по себе не доказывают причин ухода клиентов и не позволяют утверждать, что конкретный способ оплаты или тип договора является причиной оттока.
