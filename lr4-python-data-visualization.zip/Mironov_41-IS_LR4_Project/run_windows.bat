@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m telco_viz
if errorlevel 1 (
  echo.
  echo Возникла ошибка. Проверьте сообщения выше.
  pause
  exit /b 1
)
echo.
echo Готово. Результаты находятся в папке reports.
pause
