"""Запуск командой: python -m telco_viz."""

from .cli import main

if __name__ == "__main__":
    main()
