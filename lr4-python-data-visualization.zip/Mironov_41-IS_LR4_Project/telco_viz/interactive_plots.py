"""Интерактивные HTML-графики на Plotly."""
from pathlib import Path
import pandas as pd
import plotly.express as px

from . import analysis
from .config import INTERACTIVE_DIR, CHURN_COLORS, CONTRACT_COLORS


def _save_html(figure, filename: str) -> Path:
    INTERACTIVE_DIR.mkdir(parents=True, exist_ok=True)
    path = INTERACTIVE_DIR / filename
    figure.write_html(path, include_plotlyjs="cdn")
    return path


def build_interactive_figures(df: pd.DataFrame) -> list[Path]:
    outputs = []

    fig = px.histogram(
        df.dropna(subset=["TotalCharges"]), x="TotalCharges", color="Churn",
        nbins=30, barmode="overlay", opacity=0.7,
        color_discrete_map=CHURN_COLORS,
        title="Распределение суммарных платежей",
        labels={"TotalCharges": "Суммарные платежи, $", "Churn": "Отток"},
    )
    fig.update_layout(yaxis_title="Количество клиентов", width=950, height=480)
    outputs.append(_save_html(fig, "figure_1_total_charges.html"))

    _, _, rates = analysis.payment_contract_summary(df)
    fig = px.imshow(
        rates, text_auto=True, color_continuous_scale="Reds", zmin=0, zmax=60,
        title="Доля оттока: способ оплаты × тип договора",
        labels={"x": "Тип договора", "y": "Способ оплаты", "color": "Отток, %"},
    )
    outputs.append(_save_html(fig, "figure_2_payment_contract.html"))

    fig = px.line(
        analysis.vintage_by_month(df), x="tenure", y="rate", color="Contract",
        markers=True, color_discrete_map=CONTRACT_COLORS,
        title="Кривые оттока по типам договора",
        labels={"tenure": "Срок обслуживания, месяцев", "rate": "Доля оттока, %", "Contract": "Договор"},
    )
    fig.update_layout(yaxis_range=[0, 70], width=950, height=480)
    outputs.append(_save_html(fig, "figure_3_churn_curves.html"))

    payment_rate = analysis.churn_by_payment(df).round(1).rename_axis("PaymentMethod").reset_index(name="ChurnRate")
    fig = px.bar(
        payment_rate, x="ChurnRate", y="PaymentMethod", orientation="h",
        text="ChurnRate", range_x=[0, 50],
        title="Доля оттока по способу оплаты, %",
        labels={"ChurnRate": "Доля оттока, %", "PaymentMethod": "Способ оплаты"},
    )
    fig.update_traces(marker_color="#C44E52", texttemplate="%{text}%", textposition="outside")
    outputs.append(_save_html(fig, "figure_4_churn_by_payment.html"))
    return outputs
