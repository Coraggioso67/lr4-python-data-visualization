"""Загрузка и подготовка данных Telco Customer Churn."""
from pathlib import Path
import pandas as pd

from .config import DATA_DIR, DATA_FILE


def load_raw_data(path: str | Path | None = None) -> pd.DataFrame:
    """Загружает CSV из указанного пути или стандартной папки data/."""
    csv_path = Path(path) if path else DATA_DIR / DATA_FILE
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Не найден файл данных: {csv_path}. "
            f"Поместите {DATA_FILE} в папку data/ проекта."
        )
    return pd.read_csv(csv_path)


def prepare_data(raw: pd.DataFrame) -> pd.DataFrame:
    """Преобразует TotalCharges и добавляет числовой признак ChurnFlag."""
    required = {"TotalCharges", "Churn", "tenure", "MonthlyCharges", "Contract", "PaymentMethod"}
    missing = required.difference(raw.columns)
    if missing:
        raise ValueError(f"В исходной таблице отсутствуют поля: {', '.join(sorted(missing))}")

    result = raw.copy()
    result["TotalCharges"] = pd.to_numeric(result["TotalCharges"], errors="coerce")
    result["ChurnFlag"] = (result["Churn"].astype(str).str.strip() == "Yes").astype(int)
    return result


def load_data(path: str | Path | None = None) -> pd.DataFrame:
    """Выполняет полную загрузку и подготовку таблицы."""
    return prepare_data(load_raw_data(path))
