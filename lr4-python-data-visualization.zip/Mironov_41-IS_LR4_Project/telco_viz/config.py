"""Общие пути и настройки оформления проекта."""
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / "data"
REPORTS_DIR = ROOT_DIR / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
INTERACTIVE_DIR = REPORTS_DIR / "interactive"
TABLES_DIR = REPORTS_DIR / "tables"
DATA_FILE = "WA_Fn-UseC_-Telco-Customer-Churn.csv"

CHURN_COLORS = {"No": "#4C72B0", "Yes": "#C44E52"}
CONTRACT_COLORS = {
    "Month-to-month": "#C44E52",
    "One year": "#DD8452",
    "Two year": "#4C72B0",
}


def configure_plot_style() -> None:
    """Устанавливает единый стиль статических графиков."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    sns.set_theme(style="whitegrid", palette="muted")
    plt.rcParams["figure.figsize"] = (9, 4)
    plt.rcParams["figure.dpi"] = 110
    plt.rcParams["savefig.dpi"] = 140
    plt.rcParams["axes.titlesize"] = 12
