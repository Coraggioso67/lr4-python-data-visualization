"""Командный запуск анализа и сохранение всех результатов."""
import argparse
from pathlib import Path
import pandas as pd

from . import analysis
from .config import TABLES_DIR, REPORTS_DIR, configure_plot_style
from .data import load_data
from .static_plots import build_all_static_figures
from .interactive_plots import build_interactive_figures


def save_tables(df: pd.DataFrame) -> None:
    TABLES_DIR.mkdir(parents=True, exist_ok=True)
    analysis.describe_charges(df).to_csv(TABLES_DIR / "table_1_charge_statistics.csv", encoding="utf-8-sig")
    analysis.payment_contract_detail(df).to_csv(TABLES_DIR / "table_2_payment_contract.csv", index=False, encoding="utf-8-sig")
    analysis.contract_summary(df).to_csv(TABLES_DIR / "table_3_contract_churn.csv", index=False, encoding="utf-8-sig")
    analysis.churn_by_payment(df).rename("ChurnRatePercent").to_csv(TABLES_DIR / "table_4_churn_by_payment.csv", encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser(description="Лабораторная работа №4: визуализация Telco Customer Churn")
    parser.add_argument("--data", type=str, default=None, help="необязательный путь к CSV-файлу")
    parser.add_argument("--no-plotly", action="store_true", help="не создавать интерактивные HTML-графики")
    args = parser.parse_args()

    configure_plot_style()
    df = load_data(args.data)
    print("Размер таблицы после подготовки:", df.shape)
    print("Пропусков TotalCharges:", int(df["TotalCharges"].isna().sum()))
    print("Доля оттока:", f"{df['ChurnFlag'].mean() * 100:.1f}%")

    print("\nОписательные статистики:")
    print(analysis.describe_charges(df))
    counts, leavers, rates = analysis.payment_contract_summary(df)
    print("\nКоличество клиентов по способу оплаты и договору:")
    print(counts)
    print("\nДоля оттока, %:")
    print(rates)

    save_tables(df)
    static_files = build_all_static_figures(df)
    print(f"\nСоздано статических графиков: {len(static_files)}")

    if not args.no_plotly:
        interactive_files = build_interactive_figures(df)
        print(f"Создано интерактивных графиков: {len(interactive_files)}")

    summary_path = REPORTS_DIR / "run_summary.txt"
    summary_path.write_text(
        f"Строк: {len(df)}\nСтолбцов после подготовки: {df.shape[1]}\n"
        f"Пропусков TotalCharges: {int(df['TotalCharges'].isna().sum())}\n"
        f"Доля оттока: {df['ChurnFlag'].mean() * 100:.1f}%\n"
        f"Статических графиков: {len(static_files)}\n",
        encoding="utf-8",
    )
    print(f"\nРезультаты сохранены в: {REPORTS_DIR}")


if __name__ == "__main__":
    main()
