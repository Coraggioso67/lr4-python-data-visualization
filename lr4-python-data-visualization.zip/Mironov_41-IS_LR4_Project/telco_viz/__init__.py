"""Проект визуализации набора данных Telco Customer Churn."""

__version__ = "1.0.0"
