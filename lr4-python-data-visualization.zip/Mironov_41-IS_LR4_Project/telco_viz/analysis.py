"""Расчёт статистических показателей и сводных таблиц."""
import pandas as pd


def describe_charges(df: pd.DataFrame) -> pd.DataFrame:
    """Описательные статистики MonthlyCharges и TotalCharges."""
    records = {}
    for column in ("MonthlyCharges", "TotalCharges"):
        values = df[column].dropna()
        records[column] = {
            "mean": values.mean(),
            "median": values.median(),
            "std": values.std(),
            "skew": values.skew(),
            "min": values.min(),
            "max": values.max(),
        }
    return pd.DataFrame(records).round(2)


def payment_contract_summary(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Возвращает количество клиентов, число ушедших и долю оттока."""
    grouping = {"index": "PaymentMethod", "columns": "Contract"}
    counts = pd.pivot_table(df, values="ChurnFlag", aggfunc="size", **grouping)
    leavers = pd.pivot_table(df, values="ChurnFlag", aggfunc="sum", **grouping)
    rates = (pd.pivot_table(df, values="ChurnFlag", aggfunc="mean", **grouping) * 100).round(1)
    return counts, leavers, rates


def payment_contract_detail(df: pd.DataFrame) -> pd.DataFrame:
    """Таблица для отчёта: доля оттока и число ушедших из размера группы."""
    counts, leavers, rates = payment_contract_summary(df)
    rows = []
    for method in counts.index:
        row = {"PaymentMethod": method}
        for contract in counts.columns:
            row[contract] = (
                f"{rates.loc[method, contract]:.1f}% "
                f"({int(leavers.loc[method, contract])} из {int(counts.loc[method, contract])})"
            )
        rows.append(row)
    return pd.DataFrame(rows)


def contract_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Общие количество клиентов, ушедшие и доля оттока по типам договора."""
    result = (
        df.groupby("Contract", observed=False)
        .agg(clients=("ChurnFlag", "size"), churned=("ChurnFlag", "sum"), rate=("ChurnFlag", "mean"))
    )
    result["rate"] = (result["rate"] * 100).round(1)
    return result.reset_index()


def vintage_by_month(df: pd.DataFrame, min_group_size: int = 10) -> pd.DataFrame:
    """Доля оттока по месяцам обслуживания; группы меньше порога исключаются."""
    active = df.loc[df["tenure"] > 0]
    result = (
        active.groupby(["Contract", "tenure"], observed=False)
        .agg(clients=("ChurnFlag", "size"), rate=("ChurnFlag", "mean"))
        .reset_index()
    )
    result["rate"] *= 100
    return result.loc[result["clients"] >= min_group_size].copy()


def vintage_by_halfyear(df: pd.DataFrame) -> pd.DataFrame:
    """Доля оттока в полугодовых интервалах срока обслуживания."""
    active = df.loc[df["tenure"] > 0].copy()
    active["half_start"] = ((active["tenure"] - 1) // 6) * 6 + 1
    result = (
        active.groupby(["Contract", "half_start"], observed=False)
        .agg(clients=("ChurnFlag", "size"), rate=("ChurnFlag", "mean"))
        .reset_index()
    )
    result["rate"] *= 100
    result["midpoint"] = result["half_start"] + 2.5
    return result


def churn_by_payment(df: pd.DataFrame) -> pd.Series:
    """Процент оттока по каждому способу оплаты."""
    return (df.groupby("PaymentMethod")["ChurnFlag"].mean() * 100).sort_values()
