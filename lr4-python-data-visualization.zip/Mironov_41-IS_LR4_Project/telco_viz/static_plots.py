"""Создание статических графиков Matplotlib и Seaborn."""
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

from . import analysis
from .config import FIGURES_DIR, CHURN_COLORS, CONTRACT_COLORS


def save_figure(fig, filename: str) -> Path:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    target = FIGURES_DIR / filename
    fig.savefig(target, bbox_inches="tight")
    plt.close(fig)
    return target


def plot_total_matplotlib(df: pd.DataFrame) -> Path:
    fig, ax = plt.subplots()
    ax.hist(df["TotalCharges"].dropna(), bins=30, color="#4C72B0", edgecolor="white")
    ax.set(title="Распределение суммарных платежей (matplotlib)",
           xlabel="Суммарные платежи, $", ylabel="Количество клиентов")
    return save_figure(fig, "figure_1_total_matplotlib.png")


def plot_total_seaborn(df: pd.DataFrame) -> Path:
    fig, ax = plt.subplots()
    sns.histplot(data=df, x="TotalCharges", hue="Churn", bins=30,
                 element="step", stat="density", common_norm=False,
                 palette=CHURN_COLORS, ax=ax)
    ax.set(title="Суммарные платежи: ушедшие и оставшиеся (seaborn)",
           xlabel="Суммарные платежи, $", ylabel="Плотность")
    return save_figure(fig, "figure_2_total_seaborn.png")


def plot_total_static_plotly_style(df: pd.DataFrame) -> Path:
    """Статичная копия наложенной гистограммы для отчёта; интерактивная версия — в HTML."""
    fig, ax = plt.subplots()
    for churn_value, label in (("No", "Остались"), ("Yes", "Ушли")):
        values = df.loc[df["Churn"] == churn_value, "TotalCharges"].dropna()
        ax.hist(values, bins=30, alpha=0.55,
                color=CHURN_COLORS[churn_value], label=label)
    ax.set(title="Распределение суммарных платежей (статичный аналог Plotly)",
           xlabel="Суммарные платежи, $", ylabel="Количество клиентов")
    ax.legend(title="Отток")
    return save_figure(fig, "figure_3_total_plotly_static.png")


def plot_payment_contract_heatmaps(df: pd.DataFrame) -> Path:
    counts, _, rates = analysis.payment_contract_summary(df)
    fig, (left, right) = plt.subplots(1, 2, figsize=(13, 4))
    sns.heatmap(counts, annot=True, fmt=".0f", cmap="Blues", cbar=False, ax=left)
    left.set(title="Количество клиентов в группе", xlabel="Тип договора", ylabel="Способ оплаты")
    sns.heatmap(rates, annot=True, fmt=".1f", cmap="Reds", cbar=False,
                vmin=0, vmax=60, ax=right)
    right.set(title="Доля оттока, %", xlabel="Тип договора", ylabel="")
    right.set_yticklabels([])
    fig.tight_layout()
    return save_figure(fig, "figure_4_payment_contract_heatmaps.png")


def plot_vintage_curves(df: pd.DataFrame) -> Path:
    monthly = analysis.vintage_by_month(df)
    halfyear = analysis.vintage_by_halfyear(df)
    fig, (left, right) = plt.subplots(1, 2, figsize=(13, 4.5), sharey=True)
    for contract, group in monthly.groupby("Contract"):
        left.plot(group["tenure"], group["rate"], marker="o", ms=3,
                  lw=1.1, color=CONTRACT_COLORS.get(contract), label=contract)
    for contract, group in halfyear.groupby("Contract"):
        right.plot(group["midpoint"], group["rate"], marker="o", ms=4,
                   lw=1.8, color=CONTRACT_COLORS.get(contract), label=contract)
    left.set_title("По месяцам (группы не менее 10 клиентов)")
    right.set_title("По полугодиям")
    for axis in (left, right):
        axis.set_xlabel("Срок обслуживания, месяцев")
        axis.set_ylim(0, 70)
    left.set_ylabel("Доля оттока, %")
    right.legend(title="Тип договора")
    fig.tight_layout()
    return save_figure(fig, "figure_5_churn_curves.png")


def plot_distorted_comparison(df: pd.DataFrame) -> Path:
    payment_rate = analysis.churn_by_payment(df)
    fig, (left, right) = plt.subplots(1, 2, figsize=(13, 4.3))
    sns.barplot(x=payment_rate.values, y=payment_rate.index,
                color="#C44E52", ax=left)
    left.set_xlim(0, 50)
    left.set(title="Корректный график", xlabel="Доля оттока, %", ylabel="Способ оплаты")
    for y, value in enumerate(payment_rate.values):
        left.text(value + 0.5, y, f"{value:.1f}%", va="center")

    sns.barplot(x=payment_rate.index, y=payment_rate.values,
                hue=payment_rate.index,
                palette=["#FF00FF", "#00FFFF", "#FFFF00", "#00FF00"],
                legend=False, ax=right)
    right.set_ylim(14, 46)
    right.set_title("")
    right.set_xlabel("")
    right.set_ylabel("")
    right.set_xticks([])
    right.set_yticks([])
    right.grid(False)
    fig.tight_layout()
    return save_figure(fig, "figure_6_correct_vs_distorted.png")


def build_all_static_figures(df: pd.DataFrame) -> list[Path]:
    return [
        plot_total_matplotlib(df),
        plot_total_seaborn(df),
        plot_total_static_plotly_style(df),
        plot_payment_contract_heatmaps(df),
        plot_vintage_curves(df),
        plot_distorted_comparison(df),
    ]
