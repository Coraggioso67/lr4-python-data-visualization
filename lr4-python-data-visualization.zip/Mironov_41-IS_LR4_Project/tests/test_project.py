from telco_viz.data import load_data
from telco_viz.analysis import (
    describe_charges,
    payment_contract_summary,
    contract_summary,
    vintage_by_month,
)


def test_dataset_shape_and_missing_values():
    df = load_data()
    assert df.shape == (7043, 22)
    assert df["TotalCharges"].isna().sum() == 11
    assert df["ChurnFlag"].mean() == 1869 / 7043


def test_charge_statistics():
    df = load_data()
    stats = describe_charges(df)
    assert round(stats.loc["mean", "MonthlyCharges"], 1) == 64.8
    assert round(stats.loc["skew", "MonthlyCharges"], 2) == -0.22
    assert round(stats.loc["skew", "TotalCharges"], 2) == 0.96


def test_payment_and_contract_result():
    df = load_data()
    counts, leavers, rates = payment_contract_summary(df)
    assert counts.to_numpy().sum() == 7043
    assert counts.loc["Electronic check", "Month-to-month"] == 1850
    assert leavers.loc["Electronic check", "Month-to-month"] == 994
    assert rates.loc["Electronic check", "Month-to-month"] == 53.7


def test_contract_summary_and_vintage_groups():
    df = load_data()
    summary = contract_summary(df).set_index("Contract")
    assert int(summary.loc["Month-to-month", "clients"]) == 3875
    assert round(summary.loc["Month-to-month", "rate"], 1) == 42.7
    monthly = vintage_by_month(df)
    assert (monthly["clients"] >= 10).all()
